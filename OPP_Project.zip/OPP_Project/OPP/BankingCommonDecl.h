//공통 해더 및 상수선언

#ifndef __BANKING_COMMON_H__
#define __BANKING_COMMON_H__

#include<iostream>
#include<cstring>
#include<cstdlib>

using namespace std;

enum{Level_A=7,Level_B=4,Level_C=2};
enum{NORMAL=1, CREDIT=2};

#endif